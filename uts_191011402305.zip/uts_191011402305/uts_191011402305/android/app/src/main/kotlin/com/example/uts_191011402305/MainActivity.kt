package com.example.uts_191011402305

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
