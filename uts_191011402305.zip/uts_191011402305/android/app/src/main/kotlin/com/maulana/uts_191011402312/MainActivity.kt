package com.maulana.uts_191011402312

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
